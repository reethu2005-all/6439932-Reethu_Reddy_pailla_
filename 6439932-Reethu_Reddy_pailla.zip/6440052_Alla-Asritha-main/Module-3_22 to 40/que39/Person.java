public class Person {
    private String name = "Asritha";

    public void greet() {
        System.out.println("Hello, " + name + "!");
    }

    public void setName(String name) {
        this.name = name;
    }
}
