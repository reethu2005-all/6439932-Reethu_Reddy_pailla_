public class que37_Sample {
    public void greet() {
        System.out.println("Hello, bytecode!");
    }
}

