// Log welcome message to console
console.log("Welcome to the Community Portal");

// Alert when the page is fully loaded
window.addEventListener('load', () => {
    alert("Page is fully loaded. Welcome!");
});
